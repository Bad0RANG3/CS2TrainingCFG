注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖

注意！这里面的config文件PT.cfg;autoexec.cfg和J.cfg放在Counter-Strike Global Offensive\game\csgo\cfg这个目录下
其余的全部放在steam\userdata\你的Steam好友码\730\local\cfg这个目录下覆盖
